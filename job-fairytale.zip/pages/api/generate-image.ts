// 이 파일은 OpenAI API를 사용하여 DALL·E로 이미지 생성합니다.
